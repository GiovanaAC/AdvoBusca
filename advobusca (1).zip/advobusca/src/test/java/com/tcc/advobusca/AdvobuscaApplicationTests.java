package com.tcc.advobusca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvobuscaApplicationTests {

	@Test
	void contextLoads() {
	}

}
